print("""
******************************
*                            *
*     ONLINE TEST PORTAL     *
*                            *
*----------------------------*
*                            *
*     MADE TO HELP WITH      *
*     ONLINE TESTING IN      *
*     THE TIME OF COVID      *
*                            *
******************************
""")
print("""TEACHERS END""")


import csv
import matplotlib.pyplot as plt


#TEACHER LOGIN
def teacherlogin():
    d={}
    w = int(input('''What would you like to do?
                  1.Log in
                  2.Sign up\n'''))
    i = 0
    f=['USER ID','PASSWORD']
    
    with open('Teachers.csv','r') as t:
        c=csv.DictReader(t)
        for i in c:
            d[i["USER ID"]]=i['PASSWORD']
    
    while w == 1:
            lg = input('Login ID -')
            p = input('Enter password-')
            if d[lg] == p:
                tick()
                return True
            if i == 2:
                print('There are no more chances left')
                cross()
                break
            if d[lg] != p:
                print('LOGIN FAILED, PLEASE TRY AGAIN')
                print('You have ', 3-i, ' chances left')
            i += 1
            
    if w == 2:
            lg = input('Create login ID-')
            p = input('Create password-')
            d[lg] = p
            print('ID created')
            with open('teachers.csv','a') as t:
                c=csv.DictWriter(t,fieldnames=f)
                k=[{'USER ID':lg,'PASSWORD':p}]
                c.writerows(k)
            tick()
            return True


#CREATING A QUIZ/QUESTION PAPER
def crtquiz():
    import pickle
    c = input('Enter class-')
    s = input('Enter subject-')
    n = input('Enter name of quiz-')
    f = open('Ques paper'+ n +'.txt', 'w+')
    o = open('Q'+n+'.dat','wb+')
    q = int(input('Enter no of questions-'))
    Q = []
    f.write('Class-'+c+'\nSubject-'+s+'\nName of quiz-'+n+'\n')
    for i in range(q):
        ques = input('Enter question-')
        a1 = '(1)'+input('Option 1 -')
        a2 = '(2)'+input('Option 2 -')
        a3 = '(3)'+input('Option 3 -')
        a4 = '(4)'+input('Option 4 -')
        que = ques+'\n'+a1+'\n'+a2+'\n'+a3+'\n'+a4+'\n'
        cans = int(input('Correct answer -'))
        Q += [{str(i+1)+'-'+ques: [que, cans]}]
        f.write(str(i+1)+'-'+que+'\n')
        f.write('Correct answer= option-'+str(cans)+'\n')
        f.write('\n')
        print('Question added to quiz')
    print('Quiz created')
    pickle.dump(Q, o)
    o.close()
    f.close()
    tick()


#ENTERING STUDENT DATA
def studdata():
    c = int(input('Which class is this?\n'))
    sec = input('Which section?\n')
    l = []
    n = int(input('How many students are there?\n'))
    for i in range(n):
        r = int(input('Enter roll number-'))
        n = input('Enter name-')
        userid = str(c*100+r)
        pwd = userid
        l += [{'ROLL NO': r, 'NAME': n, 'USER ID': userid, 'PASSWORD': pwd}]
        print('ID= ', userid, 'Password=', pwd)
        print('Record successful')
    fields = ['ROLL NO', 'NAME', 'USER ID', 'PASSWORD']
    c1 = 'Student records-'+str(c)+'-'+sec+'.csv'
    with open(c1, 'w+') as c:
        w = csv.DictWriter(c, fieldnames=fields)
        w.writeheader()
        w.writerows(l)
    tick()

#MODIFYING STUDENT DATA
def moddata():
    c = int(input('Which class data to be modified?-'))
    sec = input('Which section?-')
    rn = int(input('Enter roll number to be modified-'))
    l = []
    c1 = 'Student records-' + str(c) + '-' + sec + '.csv'
    with open(c1, 'r') as c:
        r = csv.DictReader(c)
        h = r.fieldnames
        o = int(input('''What do you want to modify?\n
                    1.Name
                    2.User id
                    3.Password\n'''))
        for k in r:
            if int(k['ROLL NO']) == rn :
                if o == 1:
                    k['NAME'] = input('Enter new name-')
                if o == 2:
                    k['USER ID'] = input('Enter new user id-')
                if o == 3:
                    k['PASSWORD'] = input('Enter new password-')
            l += [k]
        
    with open(c1, 'w') as c:
        w = csv.DictWriter(c, fieldnames=h)
        w.writeheader()
        w.writerows(l)
        print('Data successfully modified')
    tick()


#SHOWING MARKS OF STUDENTS
def showmks():
    
    cl=int(input('Enter class-'))
    sec=input('Enter section-')
    cn='Student marks-'+str(cl)+'-'+sec+'.csv'
    
    with open(cn,'r') as d:
        dr=csv.DictReader(d)
        k=int(input('Enter roll no of the students to show marks-'))
        for i in dr:
            if int(i['ROLL NO'])==k:
                print(i)
        

#DISPLAY THE PERFORMANCE REPORT
def perf():
            cl=int(input('Enter class-'))
            sec=input('Enter section-')
            cn='Student marks-'+str(cl)+'-'+sec+'.csv'
            
            with open(cn,'r') as dd:
               dr=csv.DictReader(dd)
               nakme=[]
               nots=[]
               m=[]
               k=0
               for i in dr:
                   nakme+=[i['NAME']]
                   nots+=[i['NAME OF TEST']]
                   m+=[i['PERCENTAGE']]
                   k+=1
            
            print()
            print('PERFORMANCE REPORT-')
       
            plt.plot(nots,m)
            plt.xlabel('Name of test')
            plt.ylabel('Percentage')
            plt.title('Performance report')


#MISC
def tick():
    for i in range(10):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 or (j==12 and i>=8):
                print('*',end=' ')
            else:
                print(' ',end=' ')
        print()
    for i in range(10,0,-1):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 or (j==4 and i<=9 and i>6) or (j==2*i-8 and i>=6):
                print('*',end=' ')
            else:
                print(' ',end=' ')
        print()


def cross():
    for i in range(10):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 :
                print('*',end=' ')
            if ((j==9 or j==2*i-11) and i>6):
                print('X',end=' ')
            else:
                print(' ',end=' ')
        print()
    
    for i in range(10,0,-1):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 :
                print('*',end=' ')
            if ((j==9 or j==2*i-11) and i>6):
                print('X',end=' ')
            else:
                print(' ',end=' ')
        print()
 

#FEEDBACK
def fb():
    s=input('Please write your feedback-\n')
    f=open('Teacher feedback.txt','a')
    f.writelines(s)           


e = teacherlogin()


#MAIN PROGRAM
while e == True:
    print('Logged in successfully')
    i=int(input('''What would you like to do-
                1.Create quiz
                2.Enter student data
                3.Modify student data
                4.Display student marks
                5.display performance report\n'''))
                
                
    if i == 1:
        crtquiz()

    if i == 2:
        studdata()

    if i == 3:
        moddata()
    
    if i==4:
        showmks()
        
    if i==5:
        perf()
    h = int(input('''Would you like to do another job?
          1.Yes 
          2.No\n'''))
    if h == 1:
        continue
    else:
        break

p=int(input('''Would you like to share your feedback?
            1.Yes
            2.No\n'''))

if p==1:
    fb()