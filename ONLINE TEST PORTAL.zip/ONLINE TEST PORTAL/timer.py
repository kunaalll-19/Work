import time
def timer(k):
    l=[]
    t=time.localtime(time.time())
    a,b=t[4],t[5]
    while True:    
        z=time.localtime(time.time())
        if z[4]==a+int(k) and z[5]>=b:
            return print('TIME UP!!!!')
        if [z[4],z[5]] not in l:
            l+=[[z[4],z[5]]]
            print(z[4],z[5])
    
timer(1)