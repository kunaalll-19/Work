for i in range(10):
    for k in range(20-(2*i)):
        print(' ',end='')
    for j in range(2*i):
        if j==0 or j==2*i-1 or (j==12 and i>=8):
            print('*'*2,end=' ')
        else:
            print(' ',end=' ')
    print()
    
k=(j==3 and i>5)
for i in range(10,0,-1):
    for k in range(20-(2*i)):
        print(' ',end='')
    for j in range(2*i):
        if j==0 or j==2*i-1 or (j==4 and i<=9 and i>6) or (j==2*i-8 and i>=6):
            print('*'*2,end=' ')
        else:
            print(' ',end=' ')
    print()