print("""
******************************
*                            *
*     ONLINE TEST PORTAL     *
*                            *
*----------------------------*
*                            *
*     MADE TO HELP WITH      *
*     ONLINE TESTING IN      *
*     THE TIME OF COVID      *
*                            *
******************************
""")

print("""TEST STUDENT END""")


import pickle
import csv
import time


#LOGIN
def login():
    c = input('Class-')
    s = input('Section-')
    c1 = 'Student records-' + c +'-'+ s + '.csv'
    sname=''
    srno=0
    with open(c1,'r') as st :
        u = csv.DictReader(st)
        uid = input('Enter user id-')
        pwd = input('Enter password-')
        for i in u:
            if i['USER ID'] == uid and i['PASSWORD'] == pwd :
                print('Login successful')
                sname=i['NAME']
                srno=i['ROLL NO']
                return [sname,srno,True,c,s]
        else:
            print('User ID or password is incorrect')
            return False


#GIVE THE TEST
def givetest():
    m=0
    n=input('Enter name of test-')
    f=open('Q'+n+'.dat','rb+')
    qp=pickle.load(f)
    o=0
    for i in qp:
        o+=1
        
    t=o*2
    l=time.localtime(time.time())
    a=l[4]+t
    b=l[5]
    for i in qp:
        z=time.localtime(time.time())
        if z[4]>=a+t and z[5]>=b:
            print('TIME UP!!!')
            break
        else:
            print(list(i.values())[0][0])
            k=int(input('Enter your answer-'))
            if k==list(i.values())[0][1]:
                print('Correct answer')
                tick()
                m+=4
            else:
                print('Wrong answer')
                cross()
                m-=1
            
    return [m,o,n]


#DISPLAYING MARKS OF PREVIOUS TESTS
def showmks(r,cl,s):
    
    l=[]
    cn='Student marks-'+str(cl)+'-'+str(s)+'.csv'
    
    with open(cn,'r') as d:
        dr=csv.DictReader(d)
        
        for i in dr:
            if int(i['ROLL NO'])==int(r):
                l+=[i]
    
    return l


#SAVING MARKS OF THE TESTS
def writemks():
    f=['NAME','ROLL NO','NAME OF TEST','MARKS','PERCENTAGE']
    mkscl='Student marks-'+str(clss)+'-'+sec+'.csv'
    t=0
    try:
        with open(mkscl,'r') as d1:
            b=csv.reader(d1)
            if f not in b:
                t=0
            else:
                t=1
    except:
        t=0
    with open(mkscl,'a') as d:
        a=csv.writer(d)
        if t==0:
            a.writerow(f)
        for s in q:
            a.writerow(s)

    
#MISC
def tick():
    for i in range(10):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 or (j==12 and i>=8):
                print('*',end=' ')
            else:
                print(' ',end=' ')
        print()
    for i in range(10,0,-1):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 or (j==4 and i<=9 and i>6) or (j==2*i-8 and i>=6):
                print('*',end=' ')
            else:
                print(' ',end=' ')
        print()


def cross():
    for i in range(10):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 :
                print('*',end=' ')
            if ((j==9 or j==2*i-11) and i>6):
                print('X',end=' ')
            else:
                print(' ',end=' ')
        print()
    
    for i in range(10,0,-1):
        for k in range(20-(2*i)):
            print(' ',end='')
        for j in range(2*i):
            if j==0 or j==2*i-1 :
                print('*',end=' ')
            if ((j==9 or j==2*i-11) and i>6):
                print('X',end=' ')
            else:
                print(' ',end=' ')
        print()


#FEEDBACK
def fb():
    s=input('Please write your feedback-\n')
    f=open('Student feedback.txt','a')
    d=str(clss)+'-'+str(sec)+'\n'
    f.write(d)
    sd=str(srno)+'-'+str(sname)+'\n'
    f.write(sd)
    f.writelines(s)


#MAIN PROGRAM
q=[]          
k=0
lg=login()

while lg[2]==True:
    
    sname=lg[0]
    srno=lg[1]    
    clss=lg[3]  
    sec=lg[4]
        
    e=int(input('''What would you like to do?
                    1.Give Test
                    2.Display marks of previous test\n'''))
    if e==1:
            g=givetest()
            n=g[1]*4
            perc=(g[0]/n)*100
            print('You have scored',g[0],'that is',perc,'%')
            if perc<33:
                print('fail')
            else:
                print('pass')
            q+=[[sname,srno,g[2],g[0],perc]]
            
            writemks()
            
    if e==2:
            l=showmks(srno,clss,sec)
            for i in l:
                print(i)
        
        
    k=int(input('''Would you like to do anything else?
                    1.Yes
                    2.No\n'''))
    if k==2:
                break

p=int(input('''Would you like to share your feedback?
            1.Yes
            2.No\n'''))

if p==1:
    fb()