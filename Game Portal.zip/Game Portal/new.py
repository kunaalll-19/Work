import random
k=random.randrange(1,9)
print(k)