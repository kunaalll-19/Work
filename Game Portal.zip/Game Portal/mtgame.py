#Matchstck game
import random
print('lets play the matchstick game')
print('21 matchsticks are there')
z=[1,2,3]
s=int(input('''Shall we start
            1.Yes
            2.No\n''' ))
while s!=2:
    x = int(21)
    i = 0
    while i==0:
        if i==0:
            y=int(input('Pick some matchsticks from 1 to 3--'))
            if y>3:
                print('the no you chosse cannot be greater than 3, restart the game')
                break
            if y>x :
                print('you can only choose from the remaining matchsticks')
                break
    
            x= x-y
            if x== i:
                print('I win')
                break
        
            if x>i :
                if x<2:
                    z=[1,2]
                    n=int(random.choice(z))
                    print ('i choose --', n)
                    x=x-n
                    print ('there are ',x,' matchsticks remaining')
                else:
                    n=int(random.choice(z)) 
                    print ('i choose --', n)
                    x=x-n
                    print ('there are ',x,' matchsticks remaining')
                
            if x==0:
                print('You win')
                break
            if x<i:
                    print ("ERROR ERROR ERROR ERROR", sep='...')
                    break
            print('you can only chose from the remaining matches')
    s=int(input('''Would you like to play again
                1.Yes
                2.No\n'''))
    if s== 2:
        break