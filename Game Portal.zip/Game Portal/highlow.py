import random
print('LETS START TO PLAY GUESS THE NUMBER')
x=random.randrange(1,101)
s=int(input('''Shall we start?
            1.Yes
            2.No\n'''))
while s<2:
    i=0
    while i<5:
        s=int(input('Enter your choice-'))
        if s<x:
            print('ITS A HIGH')
        if s>x:
            print('ITS A LOW')
        if s==x:
            print('YOU WIN!!!')
            break
        i+=1
    print('The number was ',x)
    s=int(input('''Would you like to play again?
                1.Yes 
                2.No\n'''))
    if s==2:
        break
