import random
s=0
while s!=2:
    print("Lets play Rock paper scissors")
    p=int(input('''Shall we start?
            1.Yes 
            2.No\n'''))
    if p==1:
        print('There are five rounds')
        k=0
        m=0
        i=6
        while i>0:
            i=i-1 
            rps = [ 'Rock', 'Paper', 'Scissor' ]
            nr = random.choice(rps)
            a= str(input('What do you choose(Rock Paper or scissors)'))
            print('My choice is ',nr)
            if  a == 'r' or a=='R' or a=='rock' or a=="Rock" :
                if nr == ('Rock'):
                    print('Tie')
            
            if a == 'r' or a=='R' or a=='rock' or a=="Rock" :
                if nr == ('Paper'):
                    print('I win you lose')
                    k+=1
            if a == 'r' or a=='R' or a=='rock' or a=="Rock":
                if nr == ('Scissor'):
                    print ('U win i lose')
                    m+=1
            if  a == 'p' or a=='P' or a =='paper' or a =='Paper' :
                if nr == ('Paper'):
                    print('Tie')
            if a == 'p' or a=='P' or a =='paper' or a =='Paper' :
                if nr == ('Scissors'):
                    print('I win you lose')
                    k+=1
            if a == 'p' or a=='P' or a =='paper' or a =='Paper':
                if nr == ('Rock'):
                    print ('U win i lose')
                    m+=1
            if  a == 's' or a=='S' or a=='Scissor' or a=='scissor'  :
                if nr == ('Scissors'):
                    print('Tie')
            if a == 's' or a=='S' or a=='Scissor' or a=='scissor'  :
                if nr == ('Rock'):
                    print('I win you lose')
                    k+=1
            if a == 's' or a=='S' or a=='Scissor' or a=='scissor' :
                if nr == ('Paper'):
                    print ('U win i lose')
                    m+=1
                    
            if i ==1:
                break
        print('Total points are ',k,' for me ',m,'for you')
        if k>m:
                print('I win')
        elif m>k:
                print('You win')
        else:
                print('Its a tie')
    e=int(input('''Do you want to play again?
                1.Yes 
                2.No\n'''))
    s+=e
    if s==2:
        break