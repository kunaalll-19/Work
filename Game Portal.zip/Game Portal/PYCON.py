#PYCON
import webbrowser as wb

print('Hello my name is PYCON, the next generation AI.')
a=input("Whats ur name ?\n")

if a==str('Kunal') or a=='KUNAL' or a=='kunal':
        print ("Hello author")
else:
        print("hello ",a)
m=int(input('''Should we start?
        1.Yes
        2.No\n'''))
while m==1:
    b=int(input("""How r u?
        1.Fine 
        2.Not fine\n"""))
    if b ==1:
        print("Thats gr8")
        i=int(input('''Would you like to do something?
            1.Yes
            2.No\n'''))
        if i==1:
            x=int(input('''What would you like to do?
                1.See weather
                2.See time
                3.See news
                4.Do nothing\n'''))
        
            if x==1:
                wb.open('https://in.news.yahoo.com/weather/')
            if x==2:
                wb.open('https://in.search.yahoo.com/search?p=time&fr=yfp-t-fp-IN-en-IN-def&fp=1')
            if x==3:
                wb.open('https://www.bing.com/news?FORM=Z9LH4')

    if b ==2:
        x=int(input('''What would you like to do?
                1.play games
                2.play music
                3.watch movie
                4.do nothing\n'''))
        if x==1 :
            ok=int(input('''What would you like to play?
                         1.Rock paper scissors
                         2.matchstick game
                         3.Guess the number
                         4.Hangman\n'''))
            if ok==1:
                import RPS
                RPS.rps
            if ok==2:
                import mtgame
                mtgame.z
            if ok==3:
                import highlow
                highlow.x
            if ok==4:
                import hangman
                hangman
        
        if x==2:
            k=''
            j=list(input('What would you like to listen?\n'))
            for i in range(0,len(j)):
                if j[i]==' ' :
                    j[i]='%20'
                d=str(j[i])    
                k+=d
                f='https://gaana.com/search/'+k
            wb.open(str(f))
        
        if x==3:
            k=''
            j=list(input('What would you like to watch?\n'))
            for i in range(0,len(j)):
                if j[i]==' ' :
                    j[i]='+'
                d=str(j[i])    
                k+=d
                f='https://www.youtube.com/results?search_query='+k
            wb.open(f)                

    m=int(input('''Should we start again?
        1.Yes
        2.No\n'''))
    if m==2:
        break

import csv
print('Before leaving please share your feedback')
d={}
f=input('Feedback-')
r=int(input('Enter rating from 1 to 10-'))
d[a]=[f,r]
l=['Name','Feedback','Rating']

with open('feedback.csv','a') as f:
    dw=csv.DictWriter(f,fieldnames=l)
    for i in d:
        dw.writerow({'Name':i,'Feedback':d[i][0],'Rating':d[i][1]})

k=int(input('''Would you like to see the graphs of the ratings?
            1.Yes
            2.No'''))
if k==1:
    import matplotlib.pyplot as pl
    n=[]
    r=[]
    with open('feedback.csv','r') as f:
        o=csv.reader(f)
        o=list(o)
        for i in range(2,len(o),2):
            j=o[i]
            n+=[j[0]]
            r+=[j[-1]]
            
    pl.bar(n,r)
    pl.xlabel('Name')
    pl.ylabel('Rating')
print('Bye!Bye!')