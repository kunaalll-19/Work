#HANGMAN
import random
h=['Awkward','Bagpipes','Banjo','Burgler','Croquet','Crypt','Dwarves','Fervid','Fishhook','Fjord','Gazebo','Gypsy','Haiku','Haphazard','Hyphen','Ivory','Jazzy','Jiffy','Jinx','Jukebox']
print('Lets play HANGMAN')
print('You will get 15 turns')
print('Pls input all alphabets in lower case')
s=int(input('''Shall we start?
            1.Yes
            2.No\n'''))
while s<2:
    w=random.choice(h)
    w=w.lower()
    k=[]

    for i in range(len(w)):
       k+=['-']
    print()
    print(k)
    for i in range(15):
       a=input('Enter any alphabet\n')
       if a not in w:
              print('Nope,try again')
              continue
       else:
           for i in range(len(w)):
              if w[i]==a :
                     k[i]=w[i]
                     print('You are correct')
                     break
           if '-' not in k:
                  print('You win')
                  break
           print(k)
    else:
        print('Your turns have ended')
        print('You lose')
        print(w)
    s=int(input('''Would you like to play again?
                1.Yes 
                2.No\n'''))
    if s==2:
        break
